package com.example.helloworld

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
